# -*- coding: utf-8 -*-
# PROJECT : django-captcha
# TIME    : 17-5-28 下午4:32
# AUTHOR  : youngershen <younger.x.shen@gmail.com>